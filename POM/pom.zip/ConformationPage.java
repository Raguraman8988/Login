package com.adactin.pom;

public class ConformationPage {

}
