package com.adactin.pom;

public class SearchHotel {

}
