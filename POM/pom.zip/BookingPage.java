package com.adactin.pom;

public class BookingPage {

}
